CREATE VIEW 查看捐献者信息 AS
  SELECT
    `cornea_library`.`cl_donor`.`id`                  AS `号码`,
    `cornea_library`.`cl_donor`.`donorName`           AS `捐献者`,
    `cornea_library`.`cl_donor`.`donorAge`            AS `年龄`,
    `cornea_library`.`cl_donor`.`donorSex`            AS `性别`,
    `cornea_library`.`cl_donor`.`donorPS`             AS `身体情况`,
    `cornea_library`.`cl_donor`.`donorMH`             AS `疾病史`,
    `cornea_library`.`cl_donor`.`contactName`         AS `填表人姓名`,
    `cornea_library`.`cl_donor`.`contactTel`          AS `电话`,
    `cornea_library`.`cl_donor`.`contactPhone`        AS `手机`,
    `cornea_library`.`cl_donor`.`contactAddress`      AS `地址`,
    `cornea_library`.`cl_donor`.`contactCADR`         AS `填表人和捐献人关系`,
    `cornea_library`.`cl_donor`.`contactOtherMessage` AS `其他`
  FROM `cornea_library`.`cl_donor`;

